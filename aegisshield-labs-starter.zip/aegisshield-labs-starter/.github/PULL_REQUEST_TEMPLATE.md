### What does this PR change?

(new lab / fix to an existing lab / doc update / other)

### Which lab(s)?

### Testing

- [ ] I ran the setup script myself, start to finish, on a clean VM
- [ ] I followed the lab's own instructions exactly as written
- [ ] I completed the cleanup/teardown steps and confirmed nothing was left running
- OS/environment tested on:

### Checklist

- [ ] Lab has a filled-out `README.md` following `labs/_TEMPLATE/README.md`
- [ ] Script has no hardcoded secrets, personal paths, or credentials
- [ ] Added/updated the lab's row in the top-level `README.md` index
