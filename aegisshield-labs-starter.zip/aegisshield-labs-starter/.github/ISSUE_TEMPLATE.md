### Which lab is this about?

(e.g. `labs/01-windows-navigation`)

### What happened?

Describe the problem — a broken step, a confusing instruction, a script error, etc.

### What did you expect to happen?

### Environment

- Host OS:
- VM software/version:
- Lab's target OS:

### Steps to reproduce

1.
2.
3.

### Anything else?

Logs, screenshots, or error text are welcome.
