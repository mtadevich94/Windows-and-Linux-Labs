# Lab NN — [Lab Title]

> Copy this folder to `labs/NN-short-name/` and fill in every section below. Delete this note when you're done.

## Objective

One or two sentences: what skill will the student have practiced by the end of this lab?

## Overview

| | |
|---|---|
| **OS / Platform** | Windows / Linux |
| **Difficulty** | Beginner / Intermediate / Advanced |
| **Estimated time** | e.g. 30–45 minutes |
| **Roadmap path** | Which path/phase on the site this lab supports (e.g. Student → Foundations) |

## Prerequisites

- Software needed on the student's own machine (e.g. VirtualBox 7.x, Vagrant, an SSH client)
- Minimum VM specs (CPU / RAM / disk)
- Any accounts or downloads required before starting
- Anything the student should already know coming in

## Setup

Step-by-step instructions to get the VM running, e.g.:

1. Clone or download this folder.
2. Run `setup.ps1` (Windows) or `setup.sh` (Linux) — **read it first.**
3. What the script does, in plain language, and what "it worked" looks like once it finishes.

## Lab tasks

Numbered, concrete tasks — each one something the student does, not just reads:

1. Task one.
2. Task two.
3. Task three.

## Verification

How the student checks their own work — a command to run, an output to compare against, a question to answer correctly. Give them a way to know they succeeded without needing you to check it.

## Troubleshooting

Common issues and their fixes, e.g.:

- **Symptom** — likely cause, and what to do about it.

## Cleanup

Explicit teardown steps. If this spins up a cloud VM, say exactly how to destroy it. If it's local, say whether to just delete the VM or if anything else was touched on the host machine.

## Next up

Link to the next lab in sequence, or back to the relevant roadmap phase on the site.
